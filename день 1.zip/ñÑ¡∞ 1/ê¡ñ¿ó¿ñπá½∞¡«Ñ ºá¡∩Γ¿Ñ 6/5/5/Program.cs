﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите значение A: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Введите значение B: ");
        int b = int.Parse(Console.ReadLine());

        if (a != b)
        {
            if (a > b)
            {
                b = a;
            }
            else
            {
                a = b;
            }
        }
        else
        {
            a = b = 0;
        }

        Console.WriteLine("A = " + a);
        Console.WriteLine("B = " + b);

        Console.ReadKey();
    }
}
