﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите радиус первого круга: ");
        double r1 = double.Parse(Console.ReadLine());

        Console.Write("Введите радиус второго круга: ");
        double r2 = double.Parse(Console.ReadLine());

        double s1 = Math.PI * r1 * r1;
        double s2 = Math.PI * r2 * r2;
        double s3 = s1 - s2;

        Console.WriteLine("Площадь первого круга: " + s1);
        Console.WriteLine("Площадь второго круга: " + s2);
        Console.WriteLine("Площадь кольца: " + s3);

        Console.ReadKey();
    }
}
