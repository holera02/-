﻿Console.WriteLine("Хомич Владислав Иванович!") ;
Console.WriteLine("Введите символ");

int s = Console.Read();
string st = Console.ReadLine();
Console.WriteLine("Моё имя - {0", st);

Console.WriteLine("Код символа - {3}",s);
Console.WriteLine("В феврале { 0}или {1} дней", 28, 29);

//Объявите целочисленную переменную и присвойте ей свой год рождения.
int godr = 2004;
Console.WriteLine("Я родился в " + godr + " году.");

//Объявите целочисленную переменную и присвойте ей 100
int х = 100;
Console.WriteLine("х / 3 = " +х / 3);
//Получим 33. Исправьте тип переменной на double. Выполните и проверьте результат. Добавьте следующую строку:
Console.WriteLine("х / 3 = {0: #.####}" ,х/3);

Console.WriteLine("Введите Ваш средний балл в зимней сессии!");
double srbal = Double.Parse(Console.ReadLine());
