﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите номер единицы массы (1-5): ");
        int unit = int.Parse(Console.ReadLine());

        Console.Write("Введите массу тела в этой единице: ");
        double weight = double.Parse(Console.ReadLine());

        double kgWeight;
        switch (unit)
        {
            case 1:
                kgWeight = weight;
                break;
            case 2:
                kgWeight = weight / 1000000.0;
                break;
            case 3:
                kgWeight = weight / 1000.0;
                break;
            case 4:
                kgWeight = weight * 1000.0;
                break;
            case 5:
                kgWeight = weight * 100.0;
                break;
            default:
                kgWeight = 0.0;
                break;
        }

        Console.WriteLine("Масса тела в килограммах: " + kgWeight + " кг");

        Console.ReadKey();
    }
}
