﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите температуру в градусах Цельсия: ");
        double tc = double.Parse(Console.ReadLine());

        double tf = tc * 9 / 5 + 32;

        Console.WriteLine("Температура в градусах Фаренгейта: " + tf);

        Console.ReadKey();
    }
}
