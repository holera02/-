﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите вещественное число A: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите целое число N (> 0): ");
        int n = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Целые степени числа A от 1 до N:");
        double power = 1;
        for (int i = 1; i <= n; i++)
        {
            power *= a;
            Console.WriteLine("{0} в степени {1} = {2}", a, i, power);
        }

        Console.ReadKey();
    }
}
