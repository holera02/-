﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите трехзначное число: ");
        int num = int.Parse(Console.ReadLine());

        int a = num / 100;
        int b = (num / 10) % 10;
        int c = num % 10;

        int sum = a + b + c;
        int prod = a * b * c;

        Console.WriteLine("Сумма цифр: " + sum);
        Console.WriteLine("Произведение цифр: " + prod);

        Console.ReadKey();
    }
}
