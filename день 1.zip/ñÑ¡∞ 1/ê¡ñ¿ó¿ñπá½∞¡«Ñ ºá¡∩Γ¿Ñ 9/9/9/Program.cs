﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите целое число N: ");
        int n = int.Parse(Console.ReadLine());

        int k = 1;
        while (k * k <= n)
        {
            k++;
        }

        Console.WriteLine($"Наименьшее целое положительное число K, квадрат которого превосходит N, равно {k}.");
    }
}
